# Estado do HoodFiles

## Situação atual

Planejamento inicial criado. Código do aplicativo, prova técnica, engines, instaladores e testes nativos ainda não existem neste pacote.

| Etapa | Estado |
| --- | --- |
| HF-00 | A iniciar |
| HF-01 a HF-11 | Planejadas; dependências não concluídas |

Próxima tarefa: executar `prompts/00-inicio.md` e iniciar HF-00.

## Questões que precisam de evidência

- Há acesso a Windows e macOS para a prova? Registrar máquinas disponíveis.
- Qual mecanismo permite o fluxo global sem quebrar o arraste e sem privilégios excessivos?
- Quais versões mínimas e arquiteturas terão engines e testes completos?

## Registro de execução

Preencher a cada tarefa, mantendo o resumo atual no início:

```text
Tarefa:
Estado: em andamento / concluída / bloqueada
Alterações:
Decisões e evidências:
Comandos executados e resultados:
Testes nativos por SO:
Não executado e motivo:
Riscos pendentes:
Próxima tarefa elegível:
```

Não marcar uma etapa como concluída somente porque gerou código. Não usar o resultado dos checks deste pacote documental como resultado de teste do software.
